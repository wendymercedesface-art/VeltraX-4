package com.veltrax.desktop

import javafx.application.Platform
import javafx.animation.KeyFrame
import javafx.animation.KeyValue
import javafx.animation.Timeline
import javafx.util.Duration
import javafx.embed.swing.JFXPanel
import javafx.scene.media.Media
import javafx.scene.media.MediaPlayer

/** JavaFX player running on its own media thread; persists when the main window is minimized. */
class DesktopPlayer {
    private var current: MediaPlayer? = null
    private var incoming: MediaPlayer? = null
    private var crossfade: Timeline? = null
    private var crossfadeSeconds: Int = 0
    private var transitioning = false
    // Invalidates asynchronous MediaPlayer preparation callbacks after skip/seek/restart.
    private var transitionToken = 0L
    private var queue: List<DesktopSong> = emptyList()
    @Volatile var selected: DesktopSong? = null
        private set
    @Volatile var playing: Boolean = false
        private set
    @Volatile var error: String? = null
        private set
    init { JFXPanel(); Platform.setImplicitExit(false) }
    fun play(song: DesktopSong, list: List<DesktopSong>) {
        queue = list.ifEmpty { listOf(song) }
        selected = song
        error = null
        Platform.runLater {
            transitionToken++
            try {
                current?.stop(); current?.dispose()
                incoming?.stop(); incoming?.dispose(); incoming = null
                crossfade?.stop(); crossfade = null; transitioning = false
                current = MediaPlayer(Media(song.file.toURI().toASCIIString())).also { mp ->
                    mp.volume = 1.0
                    mp.setOnEndOfMedia { if (!transitioning) next() }
                    mp.setOnError { error = mp.error?.localizedMessage ?: "El formato no se puede reproducir"; playing = false }
                    mp.currentTimeProperty().addListener { _, _, time -> maybeCrossfade(time.toMillis()) }
                    mp.play()
                    playing = true
                }
            } catch (e: Exception) { error = e.localizedMessage; playing = false }
        }
    }
    fun setCrossfadeSeconds(seconds: Int) { crossfadeSeconds = seconds.coerceIn(0, 12) }
    fun crossfadeSeconds(): Int = crossfadeSeconds

    private fun maybeCrossfade(positionMs: Double) {
        if (crossfadeSeconds <= 0 || transitioning) return
        val player = current ?: return
        val total = try { player.totalDuration.toMillis() } catch (_: Exception) { -1.0 }
        val fadeMs = crossfadeSeconds * 1000.0
        if (total <= fadeMs || positionMs < total - fadeMs) return
        val index = queue.indexOfFirst { it.id == selected?.id }
        val nextSong = queue.getOrNull(index + 1) ?: return
        transitioning = true
        val token = ++transitionToken
        try {
            val nextPlayer = MediaPlayer(Media(nextSong.file.toURI().toASCIIString()))
            incoming = nextPlayer
            nextPlayer.volume = 0.0
            nextPlayer.setOnError {
                if (token == transitionToken && incoming === nextPlayer) {
                    error = nextPlayer.error?.localizedMessage ?: "No se pudo preparar la siguiente pista"
                    transitioning = false
                    nextPlayer.dispose(); incoming = null
                } else {
                    runCatching { nextPlayer.dispose() }
                }
            }
            nextPlayer.setOnReady {
                if (token != transitionToken || incoming !== nextPlayer) {
                    runCatching { nextPlayer.stop(); nextPlayer.dispose() }
                    return@setOnReady
                }
                val old = current ?: run {
                    nextPlayer.dispose(); incoming = null; transitioning = false
                    return@setOnReady
                }
                nextPlayer.play()
                crossfade = Timeline(
                    KeyFrame(Duration.ZERO, KeyValue(old.volumeProperty(), 1.0), KeyValue(nextPlayer.volumeProperty(), 0.0)),
                    KeyFrame(Duration.millis(fadeMs), KeyValue(old.volumeProperty(), 0.0), KeyValue(nextPlayer.volumeProperty(), 1.0))
                ).also { animation ->
                    animation.setOnFinished {
                        if (token != transitionToken || current !== old || incoming !== nextPlayer) {
                            runCatching { nextPlayer.stop(); nextPlayer.dispose() }
                            return@setOnFinished
                        }
                        old.stop(); old.dispose()
                        current = nextPlayer; incoming = null; crossfade = null
                        selected = nextSong; playing = true; transitioning = false
                        nextPlayer.currentTimeProperty().addListener { _, _, time -> maybeCrossfade(time.toMillis()) }
                        nextPlayer.setOnEndOfMedia { if (!transitioning) next() }
                    }
                    animation.play()
                }
            }
        } catch (e: Exception) {
            error = e.localizedMessage ?: "No se pudo iniciar el fundido"
            transitioning = false
        }
    }

    fun toggle() { Platform.runLater {
        if (playing) {
            current?.pause(); incoming?.pause(); crossfade?.pause()
            playing = false
        } else {
            current?.play(); incoming?.play(); crossfade?.play()
            playing = true
        }
    } }
    fun next() {
        val idx = queue.indexOfFirst { it.id == selected?.id }
        if (idx >= 0 && idx + 1 < queue.size) play(queue[idx + 1], queue)
        else { Platform.runLater { current?.stop() }; playing = false }
    }
    fun previous() {
        val idx = queue.indexOfFirst { it.id == selected?.id }
        if (idx > 0) play(queue[idx - 1], queue)
        else seek(0.0)
    }
    fun positionMs(): Long = try { current?.currentTime?.toMillis()?.toLong() ?: 0 } catch (_: Exception) { 0 }
    fun durationMs(): Long = try { current?.totalDuration?.toMillis()?.toLong() ?: 0 } catch (_: Exception) { 0 }
    fun seek(fraction: Double) { Platform.runLater {
        transitionToken++
        if (incoming != null) {
            crossfade?.stop(); crossfade = null
            incoming?.stop(); incoming?.dispose(); incoming = null
            current?.volume = 1.0
            transitioning = false
        }
        current?.let { player -> if (durationMs() > 0) player.seek(javafx.util.Duration.millis(durationMs() * fraction.coerceIn(0.0, 1.0))) }
    } }
    fun close() { Platform.runLater {
        transitionToken++
        crossfade?.stop(); current?.stop(); current?.dispose(); incoming?.stop(); incoming?.dispose(); Platform.exit()
    } }
}
