package com.veltrax.music

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.net.Uri
import android.content.ContentValues
import android.app.RecoverableSecurityException
import android.provider.MediaStore
import androidx.activity.result.IntentSenderRequest
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.veltrax.music.ui.VeltraXScreen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val model: MainViewModel = viewModel()
            var hasAudio by remember { mutableStateOf(hasAudioPermission()) }
            var hasNotif by remember { mutableStateOf(hasNotificationPermission()) }
            var pendingMetadataUri by remember { mutableStateOf<Uri?>(null) }
            var pendingMetadataValues by remember { mutableStateOf<ContentValues?>(null) }
            val metadataPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.StartIntentSenderForResult()
            ) { result ->
                val uri = pendingMetadataUri
                val values = pendingMetadataValues
                if (result.resultCode == android.app.Activity.RESULT_OK && uri != null && values != null) {
                    try {
                        contentResolver.update(uri, values, null, null)
                        model.refreshSongs()
                        Toast.makeText(this, "Información actualizada", Toast.LENGTH_SHORT).show()
                    } catch (error: Exception) {
                        Toast.makeText(this, "No se pudo actualizar: ${error.message}", Toast.LENGTH_LONG).show()
                    }
                } else Toast.makeText(this, "No se concedió permiso para editar este audio", Toast.LENGTH_SHORT).show()
                pendingMetadataUri = null
                pendingMetadataValues = null
            }

            val audioLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { granted ->
                hasAudio = granted
                if (granted) model.refreshSongs()
            }

            val notifLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { granted ->
                hasNotif = granted
            }
            val backupExporter = rememberLauncherForActivityResult(
                ActivityResultContracts.CreateDocument("application/vnd.veltrax.library")
            ) { uri: Uri? ->
                if (uri != null) try {
                    contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                        it.write(model.createPortableBackup())
                    } ?: error("No se pudo crear el archivo")
                    Toast.makeText(this, "Copia de biblioteca guardada", Toast.LENGTH_SHORT).show()
                } catch (error: Exception) {
                    Toast.makeText(this, "Error al guardar: ${error.message}", Toast.LENGTH_LONG).show()
                }
            }
            val backupImporter = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenDocument()
            ) { uri: Uri? ->
                if (uri != null) try {
                    val content = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("No se pudo leer el archivo")
                    Toast.makeText(this, model.restorePortableBackup(content), Toast.LENGTH_LONG).show()
                } catch (error: Exception) {
                    Toast.makeText(this, "No se pudo restaurar: ${error.message}", Toast.LENGTH_LONG).show()
                }
            }

            LaunchedEffect(hasAudio) {
                if (hasAudio) model.refreshSongs()
            }

            // Ask for notifications once (needed for download + media progress on Android 13+).
            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= 33 && !hasNotif) {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            VeltraXScreen(
                model = model,
                hasPermission = hasAudio,
                onPermission = {
                    val perm = if (Build.VERSION.SDK_INT >= 33) {
                        Manifest.permission.READ_MEDIA_AUDIO
                    } else {
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                    audioLauncher.launch(perm)
                },
                onSaveMetadata = { song, title, artist, album ->
                    val uri = Uri.parse(song.uri)
                    val values = ContentValues().apply {
                        put(MediaStore.Audio.Media.TITLE, title)
                        put(MediaStore.Audio.Media.ARTIST, artist)
                        put(MediaStore.Audio.Media.ALBUM, album)
                    }
                    try {
                        if (Build.VERSION.SDK_INT >= 30) {
                            val request = MediaStore.createWriteRequest(contentResolver, listOf(uri))
                            pendingMetadataUri = uri
                            pendingMetadataValues = values
                            metadataPermissionLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
                        } else {
                            try {
                                contentResolver.update(uri, values, null, null)
                                model.refreshSongs()
                            } catch (recoverable: RecoverableSecurityException) {
                                pendingMetadataUri = uri
                                pendingMetadataValues = values
                                metadataPermissionLauncher.launch(
                                    IntentSenderRequest.Builder(recoverable.userAction.actionIntent.intentSender).build()
                                )
                            }
                        }
                    } catch (error: Exception) {
                        Toast.makeText(this, "No se pudo solicitar permiso: ${error.message}", Toast.LENGTH_LONG).show()
                    }
                },
                onExportBackup = { backupExporter.launch("VeltraX-Biblioteca.vtxlib") },
                onImportBackup = { backupImporter.launch(arrayOf("*/*")) }
            )
        }
    }

    private fun hasAudioPermission(): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < 33) return true
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }
}
