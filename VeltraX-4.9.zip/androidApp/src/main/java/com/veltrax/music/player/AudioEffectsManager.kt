package com.veltrax.music.player

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer

/** Maps a 10-band graphic EQ onto the physical bands exposed by the device. */
object AudioEffectsManager {
    private val frequenciesHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    private val virtualLevels = FloatArray(10)
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    @Synchronized fun attach(sessionId: Int) {
        releaseEffects()
        if (sessionId <= 0) return
        try {
            equalizer = Equalizer(0, sessionId).also { eq ->
                eq.enabled = true
                applyAllBands(eq)
            }
            bassBoost = BassBoost(0, sessionId).also { it.enabled = false }
        } catch (_: Exception) {
            releaseEffects()
        }
    }

    /** index is one of the ten virtual frequency bands, not a device band index. */
    @Synchronized fun setBand(index: Int, normalized: Float) {
        if (index !in virtualLevels.indices) return
        virtualLevels[index] = normalized.coerceIn(-1f, 1f)
        equalizer?.let { eq ->
            try { applyAllBands(eq) } catch (_: Exception) { }
        }
    }

    private fun applyAllBands(eq: Equalizer) {
        val physicalCount = eq.numberOfBands.toInt()
        if (physicalCount <= 0) return
        val centers = eq.centerFreqs
        val buckets = Array(physicalCount) { mutableListOf<Float>() }
        frequenciesHz.forEachIndexed { virtualIndex, hz ->
            val targetMilliHz = hz * 1000
            val physicalIndex = centers.indices.minByOrNull { i ->
                kotlin.math.abs(centers[i].toLong() - targetMilliHz.toLong())
            } ?: 0
            buckets[physicalIndex].add(virtualLevels[virtualIndex])
        }
        val range = eq.bandLevelRange
        val min = range[0].toInt()
        val max = range[1].toInt()
        buckets.forEachIndexed { index, values ->
            if (values.isNotEmpty()) {
                val normalized = values.average().toFloat().coerceIn(-1f, 1f)
                val level = (min + (normalized + 1f) / 2f * (max - min)).toInt()
                eq.setBandLevel(index.toShort(), level.toShort())
            }
        }
    }

    @Synchronized fun setBass(enabled: Boolean, strength: Int = 700) {
        try {
            bassBoost?.let {
                it.setStrength(strength.coerceIn(0, 1000).toShort())
                it.enabled = enabled
            }
        } catch (_: Exception) { }
    }

    @Synchronized fun release() {
        releaseEffects()
    }

    private fun releaseEffects() {
        try { equalizer?.release() } catch (_: Exception) { }
        try { bassBoost?.release() } catch (_: Exception) { }
        equalizer = null
        bassBoost = null
    }
}
