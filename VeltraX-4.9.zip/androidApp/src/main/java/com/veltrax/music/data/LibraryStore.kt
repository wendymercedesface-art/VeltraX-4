package com.veltrax.music.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local user library (favorites, playlists, download queue). Survives restarts. */
class LibraryStore(context: Context) {

    private val prefs = context.getSharedPreferences("veltrax_library_2", Context.MODE_PRIVATE)

    data class Appearance(
        val palette: String = "aurora",
        val lightMode: Boolean = false,
        val compactRows: Boolean = false,
        val animations: Boolean = true
    )

    fun appearance(): Appearance = Appearance(
        palette = prefs.getString("appearance_palette", "aurora")
            ?.takeIf { it in setOf("aurora", "violet", "sunset", "emerald") } ?: "aurora",
        lightMode = prefs.getBoolean("appearance_light", false),
        compactRows = prefs.getBoolean("appearance_compact", false),
        animations = prefs.getBoolean("appearance_animations", true)
    )

    fun saveAppearance(appearance: Appearance) {
        val safePalette = appearance.palette.takeIf {
            it in setOf("aurora", "violet", "sunset", "emerald")
        } ?: "aurora"
        prefs.edit()
            .putString("appearance_palette", safePalette)
            .putBoolean("appearance_light", appearance.lightMode)
            .putBoolean("appearance_compact", appearance.compactRows)
            .putBoolean("appearance_animations", appearance.animations)
            .apply()
    }

    /** Ten virtual EQ bands, normalized to -1..1, persisted across app restarts. */
    fun equalizerBands(): List<Float> {
        val raw = prefs.getString("equalizer_bands", null) ?: return List(10) { 0f }
        return try {
            val array = JSONArray(raw)
            List(10) { index -> array.optDouble(index, 0.0).toFloat().coerceIn(-1f, 1f) }
        } catch (_: Exception) {
            List(10) { 0f }
        }
    }

    fun saveEqualizerBands(bands: List<Float>) {
        val safe = List(10) { index -> bands.getOrElse(index) { 0f }.coerceIn(-1f, 1f) }
        prefs.edit().putString("equalizer_bands", JSONArray(safe).toString()).apply()
    }

    fun bassBoostEnabled(): Boolean = prefs.getBoolean("bass_boost_enabled", false)

    fun saveBassBoostEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("bass_boost_enabled", enabled).apply()
    }

    fun favorites(): Set<String> = getArray("favorites").toSet()

    fun toggleFavorite(uri: String) {
        if (uri.isBlank()) return
        val values = favorites().toMutableSet()
        if (!values.add(uri)) values.remove(uri)
        saveArray("favorites", values.toList())
    }

    fun playlists(): Map<String, List<String>> {
        val raw = prefs.getString("playlists", "{}") ?: "{}"
        return try {
            val obj = JSONObject(raw)
            obj.keys().asSequence().associateWith { name ->
                obj.optJSONArray(name)?.let { arr ->
                    (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
                } ?: emptyList()
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun createPlaylist(name: String) {
        val clean = name.trim().take(45)
        if (clean.isEmpty()) return
        val maps = playlists().toMutableMap()
        if (!maps.containsKey(clean)) {
            maps[clean] = emptyList()
            savePlaylists(maps)
        }
    }

    fun addToPlaylist(name: String, uri: String) {
        if (uri.isBlank()) return
        val maps = playlists().toMutableMap()
        val old = maps[name] ?: return
        maps[name] = (old + uri).distinct()
        savePlaylists(maps)
    }

    fun removeFromPlaylist(name: String, uri: String) {
        val maps = playlists().toMutableMap()
        maps[name] = maps[name].orEmpty().filterNot { it == uri }
        savePlaylists(maps)
    }

    fun deletePlaylist(name: String) {
        val maps = playlists().toMutableMap()
        if (maps.remove(name) != null) savePlaylists(maps)
    }

    private fun savePlaylists(maps: Map<String, List<String>>) {
        val obj = JSONObject()
        maps.forEach { (k, v) -> obj.put(k, JSONArray(v)) }
        prefs.edit().putString("playlists", obj.toString()).apply()
    }

    private fun getArray(key: String): List<String> {
        return try {
            val arr = JSONArray(prefs.getString(key, "[]") ?: "[]")
            (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveArray(key: String, values: List<String>) {
        prefs.edit().putString(key, JSONArray(values).toString()).apply()
    }


    data class ListeningStats(val totalPlays: Int = 0, val counts: Map<String, Int> = emptyMap(), val recent: List<String> = emptyList())

    fun listeningStats(): ListeningStats {
        return try {
            val raw = JSONObject(prefs.getString("listening_stats", "{}") ?: "{}")
            val countObject = raw.optJSONObject("counts") ?: JSONObject()
            val counts = countObject.keys().asSequence().associateWith { countObject.optInt(it, 0) }
            val recentArray = raw.optJSONArray("recent") ?: JSONArray()
            val recent = (0 until recentArray.length()).map { recentArray.optString(it) }.filter { it.isNotBlank() }
            ListeningStats(raw.optInt("total", 0), counts, recent)
        } catch (_: Exception) { ListeningStats() }
    }

    fun recordPlay(uri: String) {
        if (uri.isBlank()) return
        val stats = listeningStats()
        val counts = stats.counts.toMutableMap()
        counts[uri] = (counts[uri] ?: 0) + 1
        val recent = (listOf(uri) + stats.recent.filterNot { it == uri }).take(30)
        val countJson = JSONObject().apply { counts.forEach { (key, value) -> put(key, value) } }
        val recentJson = JSONArray(recent)
        prefs.edit().putString("listening_stats", JSONObject()
            .put("total", stats.totalPlays + 1)
            .put("counts", countJson)
            .put("recent", recentJson).toString()).apply()
    }

    data class DownloadItem(
        val id: String,
        val url: String,
        val fileName: String,
        val workId: String = ""
    )

    fun downloads(): List<DownloadItem> {
        return try {
            val array = JSONArray(prefs.getString("downloads", "[]") ?: "[]")
            (0 until array.length()).mapNotNull { i ->
                val obj = array.optJSONObject(i) ?: return@mapNotNull null
                val id = obj.optString("id")
                val url = obj.optString("url")
                val fileName = obj.optString("fileName")
                if (id.isBlank() || url.isBlank() || fileName.isBlank()) null
                else DownloadItem(id, url, fileName, obj.optString("workId"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun addDownload(item: DownloadItem) {
        val current = downloads().filterNot { it.id == item.id }
        val array = JSONArray()
        (listOf(item) + current).take(100).forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("url", it.url)
                    .put("fileName", it.fileName)
                    .put("workId", it.workId)
            )
        }
        prefs.edit().putString("downloads", array.toString()).apply()
    }

    fun removeDownload(id: String) {
        val remaining = downloads().filterNot { it.id == id }
        val array = JSONArray()
        remaining.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("url", it.url)
                    .put("fileName", it.fileName)
                    .put("workId", it.workId)
            )
        }
        prefs.edit().putString("downloads", array.toString()).apply()
    }
}
