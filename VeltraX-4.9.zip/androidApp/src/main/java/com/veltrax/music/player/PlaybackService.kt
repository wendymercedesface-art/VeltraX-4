package com.veltrax.music.player

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Background playback with Media3 notification and system transport controls.
 * Handles audio focus and noisy events so playback behaves correctly on any device.
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private var activePlayer: ExoPlayer? = null
    private var fadeOutActive = false
    private var fadeInStartedAt = 0L
    private var fadeInActive = false
    private val transitionFade = object : Runnable {
        override fun run() {
            val player = activePlayer ?: return
            val fadeMs = getSharedPreferences("veltrax_playback", MODE_PRIVATE)
                .getInt("transition_fade_seconds", 0).coerceIn(0, 12) * 1000L
            if (fadeMs <= 0L) {
                player.volume = 1f
                fadeOutActive = false
                fadeInActive = false
            } else if (player.isPlaying && player.hasNextMediaItem && player.duration > 0L) {
                val remaining = player.duration - player.currentPosition
                if (remaining in 0..fadeMs) fadeOutActive = true
                if (fadeOutActive) player.volume = (remaining.toFloat() / fadeMs).coerceIn(0f, 1f)
                if (remaining > fadeMs && !fadeInActive) {
                    fadeOutActive = false
                    player.volume = 1f
                }
            }
            if (fadeInActive && fadeMs > 0L) {
                val fraction = ((SystemClock.elapsedRealtime() - fadeInStartedAt).toFloat() / fadeMs).coerceIn(0f, 1f)
                player.volume = fraction
                if (fraction >= 1f) fadeInActive = false
            }
            handler.postDelayed(this, 100L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(C.USAGE_MEDIA)
            .build()

        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        activePlayer = player
        AudioEffectsManager.attach(player.audioSessionId)
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                if (fadeOutActive) {
                    player.volume = 0f
                    fadeInStartedAt = SystemClock.elapsedRealtime()
                    fadeInActive = true
                    fadeOutActive = false
                } else {
                    player.volume = 1f
                    fadeInActive = false
                }
            }
        })
        handler.post(transitionFade)
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        handler.removeCallbacks(transitionFade)
        activePlayer = null
        AudioEffectsManager.release()
        super.onDestroy()
    }
}
