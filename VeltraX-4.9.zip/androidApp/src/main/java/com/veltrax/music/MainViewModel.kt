package com.veltrax.music

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.google.common.util.concurrent.ListenableFuture
import com.veltrax.music.data.LibraryStore
import com.veltrax.music.data.LyricsRepository
import com.veltrax.music.data.MusicRepository
import com.veltrax.music.data.Song
import com.veltrax.music.download.DownloadWorker
import com.veltrax.music.player.PlaybackService
import com.veltrax.music.player.AudioEffectsManager
import com.veltrax.core.LyricLine
import com.veltrax.core.PortableLibrary
import com.veltrax.core.PortableLibraryCodec
import com.veltrax.core.PortableTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID

data class LyricsUiState(
    val songUri: String = "",
    val lines: List<LyricLine> = emptyList(),
    val synced: Boolean = false,
    val offsetMs: Long = 0L,
    val loading: Boolean = false,
    val message: String? = null,
    val translatedLines: List<LyricLine>? = null,
    val showTranslation: Boolean = false,
    val translationLoading: Boolean = false
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = MusicRepository(app)
    private val lyricsRepository = LyricsRepository(app)
    private val library = LibraryStore(app)
    private val workManager = WorkManager.getInstance(app)

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs = _songs.asStateFlow()

    private val _favorites = MutableStateFlow(library.favorites())
    val favorites = _favorites.asStateFlow()

    private val _playlists = MutableStateFlow(library.playlists())
    val playlists = _playlists.asStateFlow()

    private val _downloads = MutableStateFlow(library.downloads())
    val downloads = _downloads.asStateFlow()

    private val _appearance = MutableStateFlow(library.appearance())
    val appearance = _appearance.asStateFlow()

    private val _workStates = MutableStateFlow<Map<String, WorkInfo>>(emptyMap())
    val workStates = _workStates.asStateFlow()

    private val _listeningStats = MutableStateFlow(library.listeningStats())
    val listeningStats = _listeningStats.asStateFlow()

    private val _nowPlaying = MutableStateFlow<Song?>(null)
    val nowPlaying = _nowPlaying.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()

    private val _position = MutableStateFlow(0L)
    val position = _position.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration = _duration.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1f)
    val playbackSpeed = _playbackSpeed.asStateFlow()
    private val _shuffleEnabled = MutableStateFlow(false)
    val shuffleEnabled = _shuffleEnabled.asStateFlow()
    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode = _repeatMode.asStateFlow()
    private val _sleepTimerSeconds = MutableStateFlow(0)
    val sleepTimerSeconds = _sleepTimerSeconds.asStateFlow()
    private val playbackPreferences = app.getSharedPreferences("veltrax_playback", Application.MODE_PRIVATE)
    private val _transitionFadeSeconds = MutableStateFlow(playbackPreferences.getInt("transition_fade_seconds", 0).coerceIn(0, 12))
    val transitionFadeSeconds = _transitionFadeSeconds.asStateFlow()
    private var sleepTimerJob: Job? = null
    private val _equalizerBands = MutableStateFlow(library.equalizerBands())
    val equalizerBands = _equalizerBands.asStateFlow()
    private val _bassBoostEnabled = MutableStateFlow(library.bassBoostEnabled())
    val bassBoostEnabled = _bassBoostEnabled.asStateFlow()

    private val _lyrics = MutableStateFlow(LyricsUiState())
    val lyrics = _lyrics.asStateFlow()

    private val _ready = MutableStateFlow(false)
    val playerReady = _ready.asStateFlow()

    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null

    init {
        connectController()
    }

    private fun connectController() {
        val context = getApplication<Application>()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        future = MediaController.Builder(context, token).buildAsync().also { f ->
            f.addListener({
                try {
                    controller = f.get().also { c ->
                        c.addListener(object : Player.Listener {
                            override fun onIsPlayingChanged(isPlaying: Boolean) {
                                _isPlaying.value = isPlaying
                            }

                            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                                mediaItem?.localConfiguration?.uri?.toString()?.let { uri ->
                                    library.recordPlay(uri)
                                    _listeningStats.value = library.listeningStats()
                                }
                                syncPlayer()
                            }

                            override fun onPlaybackStateChanged(playbackState: Int) {
                                syncPlayer()
                            }

                            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                                _isPlaying.value = false
                            }
                        })
                        _ready.value = true
                        _equalizerBands.value.forEachIndexed { index, value -> AudioEffectsManager.setBand(index, value) }
                        AudioEffectsManager.setBass(_bassBoostEnabled.value)
                        syncPlayer()
                    }
                } catch (_: Exception) {
                    _ready.value = false
                }
            }, androidx.core.content.ContextCompat.getMainExecutor(context))
        }
    }

    private fun syncPlayer() {
        val c = controller ?: return
        val uri = c.currentMediaItem?.localConfiguration?.uri?.toString()
        _nowPlaying.value = _songs.value.firstOrNull { it.uri == uri }
            ?: c.currentMediaItem?.let { item ->
                Song(
                    uri ?: "",
                    item.mediaMetadata.title?.toString() ?: "Canción",
                    item.mediaMetadata.artist?.toString() ?: "",
                    item.mediaMetadata.albumTitle?.toString() ?: "",
                    c.duration.coerceAtLeast(0)
                )
            }
        _isPlaying.value = c.isPlaying
        val pos = c.currentPosition
        val dur = c.duration
        _position.value = if (pos >= 0) pos else 0L
        _duration.value = if (dur >= 0) dur else 0L
        _shuffleEnabled.value = c.shuffleModeEnabled
        _repeatMode.value = c.repeatMode
    }

    fun refreshSongs() {
        viewModelScope.launch {
            try {
                _songs.value = repository.readAll()
                syncPlayer()
            } catch (_: SecurityException) {
                _songs.value = emptyList()
            } catch (_: Exception) {
                // Keep previous list on transient MediaStore failures.
            }
        }
    }

    fun refreshProgress() {
        val c = controller ?: return
        val pos = c.currentPosition
        val dur = c.duration
        if (pos >= 0) _position.value = pos
        if (dur >= 0) _duration.value = dur
        _isPlaying.value = c.isPlaying
    }

    fun refreshDownloads() {
        viewModelScope.launch {
            _downloads.value = library.downloads()
            val results = withContext(Dispatchers.IO) {
                try {
                    workManager.getWorkInfosByTag("veltrax").get()
                } catch (_: Exception) {
                    emptyList()
                }
            }
            val currentRequests = _downloads.value
                .filter { it.workId.isNotBlank() }
                .associate { it.workId to it.id }
            _workStates.value = results.mapNotNull { wi ->
                currentRequests[wi.id.toString()]?.let { downloadId -> downloadId to wi }
            }.toMap()
        }
    }

    fun play(song: Song, collection: List<Song>) {
        val c = controller ?: return
        val queue = collection.ifEmpty { listOf(song) }
        val startIndex = queue.indexOfFirst { it.uri == song.uri }.coerceAtLeast(0)
        val items = queue.map { s ->
            MediaItem.Builder()
                .setUri(Uri.parse(s.uri))
                .setMediaId(s.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(s.title)
                        .setArtist(s.artist)
                        .setAlbumTitle(s.album)
                        .build()
                )
                .build()
        }
        try {
            c.setMediaItems(items, startIndex, 0L)
            c.prepare()
            c.play()
            syncPlayer()
        } catch (_: Exception) {
            // Ignore invalid media items.
        }
    }

    fun togglePlayback() {
        val c = controller ?: return
        try {
            if (c.isPlaying) c.pause() else c.play()
            syncPlayer()
        } catch (_: Exception) { }
    }

    fun next() {
        try {
            controller?.seekToNextMediaItem()
            syncPlayer()
        } catch (_: Exception) { }
    }

    fun previous() {
        try {
            val c = controller ?: return
            if (c.currentPosition > 3000) {
                c.seekTo(0)
            } else {
                c.seekToPreviousMediaItem()
            }
            syncPlayer()
        } catch (_: Exception) { }
    }

    fun setPlaybackSpeed(speed: Float) {
        val safe = speed.coerceIn(0.5f, 2f)
        try {
            controller?.setPlaybackSpeed(safe)
            _playbackSpeed.value = safe
        } catch (_: Exception) { }
    }

    fun setEqualizerBand(index: Int, value: Float) {
        if (index !in 0..9) return
        val safe = value.coerceIn(-1f, 1f)
        _equalizerBands.value = _equalizerBands.value.toMutableList().also { it[index] = safe }
        library.saveEqualizerBands(_equalizerBands.value)
        AudioEffectsManager.setBand(index, safe)
    }

    fun toggleBassBoost() {
        val enabled = !_bassBoostEnabled.value
        _bassBoostEnabled.value = enabled
        library.saveBassBoostEnabled(enabled)
        AudioEffectsManager.setBass(enabled)
    }

    fun resetEqualizer() {
        _equalizerBands.value = List(10) { 0f }
        library.saveEqualizerBands(_equalizerBands.value)
        _equalizerBands.value.forEachIndexed { index, value -> AudioEffectsManager.setBand(index, value) }
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
        _shuffleEnabled.value = c.shuffleModeEnabled
    }

    fun cycleRepeatMode() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        _repeatMode.value = c.repeatMode
    }

    fun setTransitionFadeSeconds(seconds: Int) {
        val safe = seconds.coerceIn(0, 12)
        _transitionFadeSeconds.value = safe
        playbackPreferences.edit().putInt("transition_fade_seconds", safe).apply()
    }

    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepTimerSeconds.value = minutes.coerceIn(1, 180) * 60
        sleepTimerJob = viewModelScope.launch {
            while (_sleepTimerSeconds.value > 0) {
                delay(1000)
                _sleepTimerSeconds.value = (_sleepTimerSeconds.value - 1).coerceAtLeast(0)
            }
            controller?.pause()
            _isPlaying.value = false
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        _sleepTimerSeconds.value = 0
    }

    fun seek(milliseconds: Long) {
        try {
            controller?.seekTo(milliseconds.coerceAtLeast(0))
            syncPlayer()
        } catch (_: Exception) { }
    }

    fun loadLyrics(song: Song) {
        viewModelScope.launch {
            try {
                val cached = withContext(Dispatchers.IO) { lyricsRepository.cached(song.uri) }
                _lyrics.value = LyricsUiState(
                    songUri = song.uri,
                    lines = cached?.lines.orEmpty(),
                    synced = cached?.synced ?: false,
                    offsetMs = withContext(Dispatchers.IO) { lyricsRepository.offset(song.uri) },
                    message = if (cached == null) {
                        "No hay letra guardada. Puedes buscarla cuando tengas conexión."
                    } else null
                )
            } catch (error: Exception) {
                _lyrics.value = LyricsUiState(
                    songUri = song.uri,
                    offsetMs = withContext(Dispatchers.IO) { lyricsRepository.offset(song.uri) },
                    message = "No se pudo leer la letra local: ${error.message ?: "archivo dañado"}"
                )
            }
        }
    }

    fun searchLyrics(song: Song, query: String = "") {
        if (_lyrics.value.loading) return
        _lyrics.value = _lyrics.value.copy(songUri = song.uri, loading = true, message = null)
        viewModelScope.launch {
            try {
                val found = withContext(Dispatchers.IO) { lyricsRepository.lookup(song, query) }
                if (found == null) {
                    _lyrics.value = LyricsUiState(
                        songUri = song.uri,
                        offsetMs = withContext(Dispatchers.IO) { lyricsRepository.offset(song.uri) },
                        message = "No se encontró una letra para esta pista."
                    )
                } else {
                    withContext(Dispatchers.IO) { lyricsRepository.save(song.uri, found) }
                    _lyrics.value = LyricsUiState(
                        songUri = song.uri,
                        lines = found.lines,
                        synced = found.synced,
                        offsetMs = withContext(Dispatchers.IO) { lyricsRepository.offset(song.uri) },
                        message = if (found.synced) null else "La letra encontrada no tiene sincronización."
                    )
                }
            } catch (error: IOException) {
                _lyrics.value = LyricsUiState(
                    songUri = song.uri,
                    offsetMs = withContext(Dispatchers.IO) { lyricsRepository.offset(song.uri) },
                    message = "No se pudo buscar la letra: ${error.message ?: "error de red"}"
                )
            } catch (error: Exception) {
                _lyrics.value = LyricsUiState(
                    songUri = song.uri,
                    offsetMs = withContext(Dispatchers.IO) { lyricsRepository.offset(song.uri) },
                    message = "No se pudo guardar la letra: ${error.message ?: "error local"}"
                )
            }
        }
    }

    fun translateLyricsToSpanish(song: Song) {
        val current = _lyrics.value
        if (current.songUri != song.uri || current.lines.isEmpty() || current.translationLoading) return
        viewModelScope.launch {
            _lyrics.value = current.copy(translationLoading = true, message = null)
            try {
                val cached = withContext(Dispatchers.IO) { lyricsRepository.cachedTranslation(song.uri, "en", "es") }
                val translated = cached ?: withContext(Dispatchers.IO) {
                    lyricsRepository.translate(LyricsRepository.Lyrics(current.lines, current.synced), "en", "es")
                        .also { lyricsRepository.saveTranslation(song.uri, "en", "es", it) }
                }
                _lyrics.value = _lyrics.value.copy(
                    translatedLines = translated.lines,
                    showTranslation = true,
                    translationLoading = false,
                    message = "Traducción automática EN → ES. Se conserva la sincronización por línea."
                )
            } catch (error: Exception) {
                _lyrics.value = _lyrics.value.copy(
                    translationLoading = false,
                    message = "No se pudo traducir: ${error.message ?: "servicio no disponible"}"
                )
            }
        }
    }

    fun toggleLyricsTranslation() {
        val current = _lyrics.value
        if (current.translatedLines != null) {
            _lyrics.value = current.copy(showTranslation = !current.showTranslation)
        }
    }

    fun adjustLyricsOffset(song: Song, deltaMs: Long) {
        val current = _lyrics.value
        if (current.songUri != song.uri) return
        val offset = (current.offsetMs + deltaMs).coerceIn(-30_000L, 30_000L)
        _lyrics.value = current.copy(offsetMs = offset)
        viewModelScope.launch(Dispatchers.IO) { lyricsRepository.saveOffset(song.uri, offset) }
    }

    fun markNextLyricLine(song: Song, playbackPositionMs: Long) {
        val current = _lyrics.value
        if (current.songUri != song.uri || current.lines.isEmpty() || !current.synced) return
        val adjustedPosition = playbackPositionMs + current.offsetMs
        val index = current.lines.indexOfFirst { it.timestampMs > adjustedPosition }
            .takeIf { it >= 0 } ?: current.lines.lastIndex
        val updated = current.lines.toMutableList()
        updated[index] = updated[index].copy(
            timestampMs = adjustedPosition.coerceAtLeast(0L),
            words = emptyList()
        )
        val sorted = updated.sortedBy { it.timestampMs }
        _lyrics.value = current.copy(lines = sorted, message = null)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                lyricsRepository.save(song.uri, LyricsRepository.Lyrics(sorted, synced = true))
            } catch (error: IOException) {
                _lyrics.value = _lyrics.value.copy(message = "No se pudo guardar el ajuste: ${error.message}")
            }
        }
    }

    fun exportLyrics(song: Song): String? {
        val current = _lyrics.value
        if (current.songUri != song.uri || !current.synced) return null
        return try {
            val adjustedLines = current.lines.map { line ->
                line.copy(
                    timestampMs = (line.timestampMs - current.offsetMs).coerceAtLeast(0L),
                    words = line.words.map { word ->
                        word.copy(timestampMs = (word.timestampMs - current.offsetMs).coerceAtLeast(0L))
                    }
                )
            }
            lyricsRepository.export(LyricsRepository.Lyrics(adjustedLines, synced = true))
        } catch (error: IllegalArgumentException) {
            _lyrics.value = current.copy(message = error.message)
            null
        }
    }

    fun createPortableBackup(): String {
        val byUri = _songs.value.associateBy { it.uri }
        fun portable(uri: String): PortableTrack? = byUri[uri]?.let {
            PortableTrack(it.title, it.artist, it.album)
        }
        val snapshot = PortableLibrary(
            favorites = library.favorites().mapNotNull(::portable),
            playlists = library.playlists().mapValues { (_, uris) -> uris.mapNotNull(::portable) }
        )
        return PortableLibraryCodec.encode(snapshot)
    }

    fun restorePortableBackup(content: String): String {
        val snapshot = PortableLibraryCodec.decode(content)
        val local = _songs.value.associateBy { PortableLibraryCodec.key(PortableTrack(it.title, it.artist, it.album)) }
        var favoritesAdded = 0
        snapshot.favorites.forEach { track ->
            val uri = local[PortableLibraryCodec.key(track)]?.uri ?: return@forEach
            if (uri !in library.favorites()) { library.toggleFavorite(uri); favoritesAdded++ }
        }
        var playlistTracksAdded = 0
        snapshot.playlists.forEach playlistLoop@{ (name, tracks) ->
            library.createPlaylist(name)
            tracks.forEach trackLoop@{ track ->
                val uri = local[PortableLibraryCodec.key(track)]?.uri ?: return@trackLoop
                val before = library.playlists()[name].orEmpty().size
                library.addToPlaylist(name, uri)
                if (library.playlists()[name].orEmpty().size > before) playlistTracksAdded++
            }
        }
        _favorites.value = library.favorites()
        _playlists.value = library.playlists()
        return "Copia restaurada: $favoritesAdded favoritos y $playlistTracksAdded canciones en playlists."
    }

    fun toggleFavorite(uri: String) {
        if (uri.isBlank()) return
        library.toggleFavorite(uri)
        _favorites.value = library.favorites()
    }

    fun updateAppearance(appearance: LibraryStore.Appearance) {
        library.saveAppearance(appearance)
        _appearance.value = library.appearance()
    }

    fun createPlaylist(name: String) {
        library.createPlaylist(name)
        _playlists.value = library.playlists()
    }

    fun addToPlaylist(name: String, uri: String) {
        library.addToPlaylist(name, uri)
        _playlists.value = library.playlists()
    }

    fun removeFromPlaylist(name: String, uri: String) {
        library.removeFromPlaylist(name, uri)
        _playlists.value = library.playlists()
    }

    fun deletePlaylist(name: String) {
        library.deletePlaylist(name)
        _playlists.value = library.playlists()
    }

    /** Creates local smart mixes from listening history and favorites. */
    fun createSmartPlaylist(kind: String): String? {
        val available = _songs.value.associateBy { it.uri }
        val stats = library.listeningStats()
        val selected = when (kind) {
            "Más escuchadas" -> stats.counts.entries.sortedByDescending { it.value }
                .mapNotNull { available[it.key] }.take(30)
            "Escuchadas recientemente" -> stats.recent.mapNotNull { available[it] }.take(30)
            "Favoritas" -> _favorites.value.mapNotNull { available[it] }.take(30)
            else -> emptyList()
        }
        if (selected.isEmpty()) return null
        val name = "Mix $kind"
        library.createPlaylist(name)
        selected.forEach { library.addToPlaylist(name, it.uri) }
        _playlists.value = library.playlists()
        return name
    }

    fun playRecentHistory() {
        val available = _songs.value.associateBy { it.uri }
        val recent = library.listeningStats().recent.mapNotNull { available[it] }
        recent.firstOrNull()?.let { play(it, recent) }
    }

    fun enqueue(url: String, filename: String) {
        val trimmedUrl = url.trim()
        val trimmedName = filename.trim()
        val validUrl = try {
            val u = java.net.URI(trimmedUrl)
            u.scheme in listOf("https", "http") && !u.host.isNullOrBlank()
        } catch (_: Exception) {
            false
        }
        if (!validUrl || trimmedName.isBlank()) return

        val id = UUID.randomUUID().toString()
        val item = LibraryStore.DownloadItem(id, trimmedUrl, trimmedName)
        library.addDownload(item)
        _downloads.value = library.downloads()
        submit(item)
    }

    fun enqueueBulk(input: String): Int {
        val urls = Regex("""https?://[^\s,;"<>]+""", RegexOption.IGNORE_CASE)
            .findAll(input)
            .map { it.value.trimEnd('.', ')', ']', '}') }
            .distinct()
            .toList()
        var added = 0
        urls.forEachIndexed { index, rawUrl ->
            val url = Regex("^https?://", RegexOption.IGNORE_CASE)
                .replace(rawUrl) { it.value.lowercase() }
            val filename = try {
                val pathName = java.net.URI(url).path.substringAfterLast('/')
                java.net.URLDecoder.decode(pathName, Charsets.UTF_8.name())
                    .takeIf { it.isNotBlank() } ?: "Descarga ${index + 1}.mp3"
            } catch (_: Exception) {
                "Descarga ${index + 1}.mp3"
            }
            val valid = try {
                val parsed = java.net.URI(url)
                parsed.scheme in listOf("https", "http") && !parsed.host.isNullOrBlank()
            } catch (_: Exception) {
                false
            }
            if (!valid) return@forEachIndexed
            enqueue(url, filename)
            added++
        }
        return added
    }

    private fun submit(item: LibraryStore.DownloadItem) {
        val request = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(
                Data.Builder()
                    .putString(DownloadWorker.URL, item.url)
                    .putString(DownloadWorker.NAME, item.fileName)
                    .putString(DownloadWorker.ID, item.id)
                    .build()
            )
            .addTag("veltrax")
            .addTag("file:${item.id}")
            .build()
        library.addDownload(item.copy(workId = request.id.toString()))
        _downloads.value = library.downloads()
        workManager.enqueueUniqueWork(
            "veltrax:${item.id}",
            ExistingWorkPolicy.REPLACE,
            request
        )
        refreshDownloads()
    }

    fun pause(item: LibraryStore.DownloadItem) {
        workManager.cancelUniqueWork("veltrax:${item.id}")
        refreshDownloads()
    }

    fun resume(item: LibraryStore.DownloadItem) {
        submit(item)
    }

    fun removeDownload(item: LibraryStore.DownloadItem) {
        workManager.cancelUniqueWork("veltrax:${item.id}")
        library.removeDownload(item.id)
        _downloads.value = library.downloads()
        refreshDownloads()
    }

    override fun onCleared() {
        sleepTimerJob?.cancel()
        future?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onCleared()
    }
}
