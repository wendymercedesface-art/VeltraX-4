package com.veltrax.music.data

import android.content.Context
import com.veltrax.core.LrcLyrics
import com.veltrax.core.LyricLine
import com.veltrax.core.LyricWord
import com.veltrax.core.LyricsFileParser
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

class LyricsRepository(context: Context) {
    data class Lyrics(val lines: List<LyricLine>, val synced: Boolean)

    private val cacheDirectory = java.io.File(context.filesDir, "lyrics").apply { mkdirs() }
    private val preferences = context.getSharedPreferences("veltrax_lyrics", Context.MODE_PRIVATE)

    fun cached(trackUri: String): Lyrics? {
        val file = cacheFile(trackUri)
        if (!file.isFile) return null
        val root = JSONObject(file.readText())
        val lines = root.optJSONArray("lines") ?: JSONArray()
        return Lyrics(
            lines.toLines(),
            root.optBoolean("synced", false)
        )
    }

    fun offset(trackUri: String): Long = preferences.getLong(preferenceKey(trackUri), 0L)

    fun saveOffset(trackUri: String, milliseconds: Long) {
        preferences.edit().putLong(preferenceKey(trackUri), milliseconds).apply()
    }

    fun save(trackUri: String, lyrics: Lyrics) {
        val root = JSONObject()
            .put("synced", lyrics.synced)
            .put("lines", JSONArray().apply {
                lyrics.lines.forEach { line ->
                    put(
                        JSONObject()
                            .put("timestampMs", line.timestampMs)
                            .put("text", line.text)
                            .put("words", JSONArray().apply {
                                line.words.forEach { word ->
                                    put(JSONObject().put("text", word.text).put("timestampMs", word.timestampMs))
                                }
                            })
                    )
                }
            })
        val target = cacheFile(trackUri)
        val temporary = java.io.File(target.parentFile, "${target.name}.tmp")
        temporary.writeText(root.toString())
        try {
            Files.move(
                temporary.toPath(),
                target.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING
            )
        } catch (_: java.nio.file.AtomicMoveNotSupportedException) {
            Files.move(temporary.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        } catch (error: IOException) {
            temporary.delete()
            throw IOException("No se pudo guardar la letra en el almacenamiento local", error)
        }
    }

    fun lookup(song: Song, query: String = ""): Lyrics? {
        val trackName = query.trim().ifBlank { song.title }
        val exact = (fetch(
            "/api/get?track_name=${encode(trackName)}&artist_name=${encode(song.artist)}&duration=${(song.duration / 1000).coerceAtLeast(1)}"
        ) as? JSONObject)?.let(::fromResponse)
        if (exact?.synced == true) return exact

        val searchTerm = listOf(trackName, song.artist).filter { it.isNotBlank() }.joinToString(" ")
        val results = fetch("/api/search?q=${encode(searchTerm)}") as? JSONArray ?: return exact
        val candidates = (0 until results.length()).mapNotNull { results.optJSONObject(it) }
        val chosen = candidates.firstOrNull {
            it.optBoolean("hasWordSync") && it.optString("lyricsfile").isNotBlank() &&
                it.optString("trackName").equals(trackName, ignoreCase = true) &&
                it.optString("artistName").equals(song.artist, ignoreCase = true)
        } ?: candidates.firstOrNull {
            it.optString("syncedLyrics").isNotBlank() &&
                it.optString("trackName").equals(trackName, ignoreCase = true) &&
                it.optString("artistName").equals(song.artist, ignoreCase = true)
        } ?: candidates.firstOrNull { it.optString("syncedLyrics").isNotBlank() }
            ?: candidates.firstOrNull { it.optString("plainLyrics").isNotBlank() }
        return chosen?.let(::fromResponse) ?: exact
    }

    fun cachedTranslation(trackUri: String, source: String, target: String): Lyrics? =
        cached("$trackUri|translation|$source|$target")

    fun saveTranslation(trackUri: String, source: String, target: String, lyrics: Lyrics) =
        save("$trackUri|translation|$source|$target", lyrics)

    fun translate(lyrics: Lyrics, source: String = "en", target: String = "es"): Lyrics {
        require(source.matches(Regex("[a-zA-Z-]{2,12}")) && target.matches(Regex("[a-zA-Z-]{2,12}")))
        val translated = lyrics.lines.mapIndexed { index, line ->
            if (index > 0) Thread.sleep(350L)
            if (line.text.isBlank()) line.copy(words = emptyList())
            else line.copy(text = translateSegmented(line.text, source, target), words = emptyList())
        }
        return Lyrics(translated, lyrics.synced)
    }

    private fun translateSegmented(text: String, source: String, target: String): String {
        val chunks = mutableListOf<String>()
        var current = StringBuilder()
        text.split(Regex("\\s+")).forEach { word ->
            val candidate = if (current.isEmpty()) word else "$current $word"
            if (candidate.toByteArray(Charsets.UTF_8).size > 450 && current.isNotEmpty()) {
                chunks += current.toString()
                current = StringBuilder(word)
            } else current = StringBuilder(candidate)
        }
        if (current.isNotEmpty()) chunks += current.toString()
        return chunks.joinToString(" ") { chunk -> translateChunk(chunk, source, target) }
    }

    private fun translateChunk(text: String, source: String, target: String): String {
        val url = URL("https://api.mymemory.translated.net/get?q=${encode(text)}&langpair=${encode("$source|$target")}&mt=1")
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 15_000
            connection.readTimeout = 20_000
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("User-Agent", "VeltraX/4.9 (music player)")
            val status = connection.responseCode
            if (status !in 200..299) throw IOException("Servicio de traducción respondió HTTP $status")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            val responseStatus = root.optInt("responseStatus", 200)
            if (responseStatus !in 200..299) throw IOException(root.optString("responseDetails", "No se pudo traducir la letra"))
            val result = root.optJSONObject("responseData")?.optString("translatedText").orEmpty()
            if (result.isBlank() || result.startsWith("MYMEMORY WARNING", true)) {
                throw IOException("El servicio no devolvió una traducción válida")
            }
            return result
        } finally { connection.disconnect() }
    }

    fun export(lyrics: Lyrics): String {
        require(lyrics.synced) { "Solo se pueden exportar letras sincronizadas como LRC" }
        return LrcLyrics.export(lyrics.lines)
    }

    private fun fromResponse(response: JSONObject): Lyrics? {
        val lyricsFile = response.optString("lyricsfile", "").takeIf { it.isNotBlank() }
        if (lyricsFile != null) {
            try {
                val wordSynced = LyricsFileParser.parse(lyricsFile)
                if (wordSynced.isNotEmpty()) return Lyrics(wordSynced, synced = true)
            } catch (_: Exception) { /* Fall back to the stable LRC/plain fields below. */ }
        }
        val syncedText = response.optString("syncedLyrics", "").takeIf { it.isNotBlank() }
        if (syncedText != null) {
            val lines = LrcLyrics.parse(syncedText)
            if (lines.isNotEmpty()) return Lyrics(lines, synced = true)
        }
        val plainText = response.optString("plainLyrics", "").takeIf { it.isNotBlank() } ?: return null
        val lines = plainText.lineSequence().map(String::trim).filter(String::isNotEmpty)
            .mapIndexed { index, text -> LyricLine(index * 4_000L, text) }.toList()
        return lines.takeIf { it.isNotEmpty() }?.let { Lyrics(it, synced = false) }
    }

    private fun fetch(path: String): Any? {
        val url = URL("https://lrclib.net$path")
        var lastFailure: IOException? = null
        repeat(2) { attempt ->
            val connection = url.openConnection() as HttpURLConnection
            try {
                connection.requestMethod = "GET"
                connection.connectTimeout = 15_000
                connection.readTimeout = 15_000
                connection.setRequestProperty("Accept", "application/json")
                connection.setRequestProperty("User-Agent", "VeltraX/4.9 (local music player)")
                val status = connection.responseCode
                if (status == HttpURLConnection.HTTP_NOT_FOUND) return null
                if (status !in 200..299) throw IOException("LRCLIB respondió HTTP $status")
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                return if (body.trimStart().startsWith("[")) JSONArray(body) else JSONObject(body)
            } catch (error: IOException) {
                lastFailure = error
                if (attempt == 1) throw error
            } finally {
                connection.disconnect()
            }
        }
        throw lastFailure ?: IOException("No se pudo consultar LRCLIB")
    }

    private fun cacheFile(trackUri: String): java.io.File =
        java.io.File(cacheDirectory, "${hash(trackUri)}.json")

    private fun preferenceKey(trackUri: String): String = "offset_${hash(trackUri)}"

    private fun hash(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }

    private fun encode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())

    private fun JSONArray.toLines(): List<LyricLine> = (0 until length()).mapNotNull { index ->
        val line = optJSONObject(index) ?: return@mapNotNull null
        val words = line.optJSONArray("words") ?: JSONArray()
        LyricLine(
            line.optLong("timestampMs"),
            line.optString("text"),
            (0 until words.length()).mapNotNull { wordIndex ->
                val word = words.optJSONObject(wordIndex) ?: return@mapNotNull null
                LyricWord(word.optString("text"), word.optLong("timestampMs"))
            }
        )
    }
}
