package com.veltrax.core

import org.yaml.snakeyaml.LoaderOptions
import org.yaml.snakeyaml.Yaml
import org.yaml.snakeyaml.constructor.SafeConstructor

/** Parser for LRCLIB's open Lyricsfile YAML 1.0 subset. */
object LyricsFileParser {
    fun parse(content: String): List<LyricLine> {
        if (content.isBlank()) return emptyList()
        val yaml = Yaml(SafeConstructor(LoaderOptions()))
        val root = yaml.load<Any?>(content) as? Map<*, *> ?: return emptyList()
        val rows = root["lines"] as? List<*> ?: return emptyList()
        return rows.mapNotNull { row ->
            val map = row as? Map<*, *> ?: return@mapNotNull null
            val text = map["text"]?.toString().orEmpty()
            val start = map["start_ms"].asLongOrNull() ?: return@mapNotNull null
            val words = (map["words"] as? List<*>).orEmpty().mapNotNull { word ->
                val wordMap = word as? Map<*, *> ?: return@mapNotNull null
                val wordText = wordMap["text"]?.toString() ?: return@mapNotNull null
                val wordStart = wordMap["start_ms"].asLongOrNull() ?: return@mapNotNull null
                LyricWord(wordText, wordStart)
            }
            LyricLine(start, text, words)
        }.sortedBy { it.timestampMs }
    }

    private fun Any?.asLongOrNull(): Long? = when (this) {
        is Number -> toLong()
        is String -> toLongOrNull()
        else -> null
    }
}
