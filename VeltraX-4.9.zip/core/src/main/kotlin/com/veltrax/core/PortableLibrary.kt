package com.veltrax.core

import java.util.Base64

/** Portable library snapshot. Track identity is metadata-based, never a platform URI/path. */
data class PortableTrack(val title: String, val artist: String, val album: String)
data class PortableLibrary(val favorites: List<PortableTrack>, val playlists: Map<String, List<PortableTrack>>)

object PortableLibraryCodec {
    private const val HEADER = "VELTRAX_LIBRARY_1"
    private fun enc(value: String): String = Base64.getUrlEncoder().withoutPadding()
        .encodeToString(value.toByteArray(Charsets.UTF_8))
    private fun dec(value: String): String = String(Base64.getUrlDecoder().decode(value), Charsets.UTF_8)

    fun encode(library: PortableLibrary): String = buildString {
        append(HEADER).append('\n')
        library.favorites.distinct().forEach { track ->
            append("F|").append(enc(track.artist)).append('|').append(enc(track.title)).append('|')
                .append(enc(track.album)).append('\n')
        }
        library.playlists.toSortedMap().forEach { (name, tracks) ->
            tracks.distinct().forEach { track ->
                append("P|").append(enc(name)).append('|').append(enc(track.artist)).append('|')
                    .append(enc(track.title)).append('|').append(enc(track.album)).append('\n')
            }
        }
    }

    fun decode(content: String): PortableLibrary {
        val rows = content.lineSequence().filter(String::isNotBlank).toList()
        require(rows.firstOrNull() == HEADER) { "El archivo no es una copia VeltraX compatible." }
        val favorites = mutableListOf<PortableTrack>()
        val playlists = linkedMapOf<String, MutableList<PortableTrack>>()
        rows.drop(1).forEachIndexed { index, row ->
            val parts = row.split('|')
            try {
                when (parts.firstOrNull()) {
                    "F" -> {
                        require(parts.size == 4)
                        favorites += PortableTrack(dec(parts[2]), dec(parts[1]), dec(parts[3]))
                    }
                    "P" -> {
                        require(parts.size == 5)
                        playlists.getOrPut(dec(parts[1])) { mutableListOf() } +=
                            PortableTrack(dec(parts[3]), dec(parts[2]), dec(parts[4]))
                    }
                    else -> throw IllegalArgumentException("Registro desconocido")
                }
            } catch (error: Exception) {
                throw IllegalArgumentException("Copia dañada en la línea ${index + 2}.", error)
            }
        }
        return PortableLibrary(favorites.distinct(), playlists.mapValues { it.value.distinct() })
    }

    // Album is retained as descriptive metadata but title + artist form the cross-device key.
    fun key(track: PortableTrack): String = listOf(track.title, track.artist)
        .joinToString("\u0000") { it.trim().lowercase() }
}
