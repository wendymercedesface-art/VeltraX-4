package com.veltrax.core

import kotlin.test.Test
import kotlin.test.assertEquals

class LyricsFileParserTest {
    @Test fun parsesWordTimedLyricsfile() {
        val yaml = """
            version: '1.0'
            lines:
              - text: 'Stay until dawn'
                start_ms: 4200
                words:
                  - text: 'Stay '
                    start_ms: 4200
                  - text: 'until '
                    start_ms: 4800
                  - text: 'dawn'
                    start_ms: 5400
        """.trimIndent()
        val lines = LyricsFileParser.parse(yaml)
        assertEquals(1, lines.size)
        assertEquals(4200L, lines.single().timestampMs)
        assertEquals(listOf("Stay ", "until ", "dawn"), lines.single().words.map { it.text })
        assertEquals(listOf(4200L, 4800L, 5400L), lines.single().words.map { it.timestampMs })
    }
}
