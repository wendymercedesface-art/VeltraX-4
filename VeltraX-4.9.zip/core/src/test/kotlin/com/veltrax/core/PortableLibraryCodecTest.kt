package com.veltrax.core

import kotlin.test.Test
import kotlin.test.assertEquals

class PortableLibraryCodecTest {
    @Test fun roundTripsFavoritesAndPlaylistsWithUnicodeAndDelimiters() {
        val source = PortableLibrary(
            favorites = listOf(PortableTrack("Mi canción | 1", "Artista ñ", "Álbum")),
            playlists = mapOf("Favoritas / noche" to listOf(PortableTrack("Mi canción | 1", "Artista ñ", "Álbum")))
        )
        assertEquals(source, PortableLibraryCodec.decode(PortableLibraryCodec.encode(source)))
    }
}
