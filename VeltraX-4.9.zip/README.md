# VeltraX 4.9 — Android + Windows

Reproductor de música local con aplicaciones nativas separadas para Android y Windows. Android usa Kotlin, Jetpack Compose, Media3, MediaStore y WorkManager. Windows usa Compose Desktop y JavaFX Media. El módulo `:core` comparte el motor de descargas directas y el formato portable de biblioteca.

## Funciones incluidas

- Biblioteca local, búsqueda, favoritos, playlists manuales e inteligentes e historial de reproducciones.
- Reproducción en segundo plano en Android con MediaSession, controles del sistema, widget, audio focus y manejo de desconexión de auriculares.
- Reproducción Windows con mini reproductor, cola y controles de transporte.
- Velocidad, aleatorio, repetición y temporizador de apagado.
- Ecualizador virtual de diez bandas y Bass Boost en Android. El resultado depende de los efectos que exponga el fabricante.
- Letras LRCLIB con caché, sincronización por línea, Lyricsfile con marcas por palabra cuando el proveedor las ofrece, ajuste de offset, edición de sincronización y exportación LRC.
- Traducción de letras de inglés a español mediante MyMemory. Se traduce línea por línea y se conserva la sincronización por línea, pero la traducción no mantiene la sincronización palabra por palabra. El servicio gratuito tiene un límite diario y puede no estar disponible; el texto de las letras se envía al servicio externo para traducirlo.
- Descargas HTTP/HTTPS de archivos de audio directos, con comprobación de tipo, segmentos Range cuando el servidor los soporta y conservación de partes para reanudar después de pausar o perder conexión.
- Editor de etiquetas de audio en Windows mediante jaudiotagger (título, artista y álbum). En Android, el editor actualiza los metadatos indexados por MediaStore y solicita permiso al sistema; no reescribe las etiquetas ID3 dentro del archivo.
- Crossfade con solapamiento de pistas en Windows. Android ofrece un fundido de salida/entrada configurable, sin solapar dos pistas.
- Copia portable `.vtxlib` de favoritos y playlists que se puede exportar/importar entre Android y Windows. La asociación de pistas se hace por título y artista; si los nombres no coinciden, algunas entradas no se podrán vincular. No es sincronización automática en la nube.
- Preferencias del ecualizador, Bass Boost, apariencia y fundido guardadas localmente.

## Límites y seguridad

- No extrae audio de YouTube, Spotify ni servicios con DRM, ni evade controles de acceso.
- Solo acepta enlaces HTTP/HTTPS directos a archivos de audio que el usuario tenga permiso para descargar.
- La traducción requiere internet y está sujeta a límites y disponibilidad de MyMemory.
- La sincronización entre dispositivos es manual mediante exportación/importación del archivo `.vtxlib`; no sincroniza archivos de música ni rutas locales.
- La reproducción, los efectos de audio, MediaStore y los formatos compatibles dependen del dispositivo, sistema operativo y códecs disponibles.

## Compilar Android

1. Abrir la carpeta raíz en Android Studio con JDK 17.
2. Instalar Android SDK Platform 35 y Build Tools 35.0.0.
3. Usar el wrapper Gradle 8.14.3 (AGP 8.11.1 y Kotlin 2.2.20).
4. Ejecutar `./gradlew :androidApp:assembleDebug`.
5. El APK de depuración queda en `androidApp/build/outputs/apk/debug/`.

El workflow `.github/workflows/android-apk.yml` compila el APK y lo publica como artefacto de GitHub Actions.

## Compilar Windows

Con JDK 17 y Windows, ejecutar `gradle :desktopApp:packageMsi` o abrir el proyecto en IntelliJ IDEA/Android Studio y ejecutar la tarea equivalente. El workflow `.github/workflows/windows-msi.yml` construye el instalador MSI.

## Estado de verificación de esta entrega

Se verificó la integridad del archivo ZIP y se añadieron pruebas unitarias para el parser Lyricsfile y el formato portable de biblioteca. No se pudo ejecutar Gradle en este entorno: el wrapper necesita descargar Gradle 8.14.3 desde `services.gradle.org` y la resolución DNS de ese host no está disponible. Por tanto, esta entrega no incluye un APK/MSI compilado y no debe distribuirse como compilación certificada hasta que pasen los workflows o la compilación local.


## VeltraX 4.9 — correcciones de cierre

- Se endureció el crossfade de Windows frente a cambios de pista, búsqueda asíncrona del siguiente archivo y desplazamiento manual: callbacks obsoletos ya no deben reemplazar el reproductor activo.
- El editor de etiquetas de Windows ahora precarga el álbum actual para evitar borrarlo accidentalmente al editar solo título o artista.
- Se aclaró que la asociación de biblioteca portable usa título + artista como clave, y que el álbum es descriptivo.

## Alcance exacto de las seis mejoras solicitadas

1. Crossfade: solapamiento real en Windows; en Android se ofrece fundido de salida/entrada porque el reproductor Android usa una sola instancia Media3.
2. Etiquetas: escritura de etiquetas del archivo en Windows con jaudiotagger; Android actualiza los metadatos de MediaStore con autorización del usuario, no reescribe el ID3 interno.
3. Descargas reanudables: partes persistentes y Range HTTP cuando el servidor lo admite; las descargas directas se limitan a audio permitido por el usuario.
4. Biblioteca entre sistemas: exportación/importación manual `.vtxlib` en ambos sistemas; no hay nube ni sincronización automática.
5. Letras: LRCLIB/Lyricsfile, resaltado por palabra cuando hay marcas de tiempo, y traducción EN→ES opcional; la traducción conserva tiempos por línea, no por palabra.
6. Interfaz: preferencias guardadas, ajustes de reproducción, apariencia, controles y mini reproductor de Windows; la certificación visual y de dispositivos requiere pruebas manuales.

## Verificación rápida del módulo compartido

Con Kotlin compiler (`kotlinc`) instalado, ejecutar `tools/verify-core.sh`. Este smoke test comprueba el formato portable, LRC con marcas por palabra y pausa/reanudación HTTP Range usando un servidor local temporal.
