import com.veltrax.core.DirectAudioDownloader
import com.veltrax.core.PortableLibrary
import com.veltrax.core.PortableLibraryCodec
import com.veltrax.core.PortableTrack
import com.veltrax.core.LrcLyrics
import com.veltrax.core.LyricLine
import com.veltrax.core.LyricWord
import com.sun.net.httpserver.HttpServer
import java.io.File
import java.net.InetSocketAddress
import java.nio.file.Files
import java.util.concurrent.atomic.AtomicBoolean

fun main() {
    val snapshot = PortableLibrary(
        listOf(PortableTrack("Canción | uno", "Artista ñ", "Álbum")),
        mapOf("Lista / noche" to listOf(PortableTrack("Canción | uno", "Artista ñ", "Álbum")))
    )
    check(PortableLibraryCodec.decode(PortableLibraryCodec.encode(snapshot)) == snapshot)
    val karaoke = listOf(LyricLine(1_000L, "Hola mundo", listOf(LyricWord("Hola ", 1_000L), LyricWord("mundo", 1_500L))))
    check(LrcLyrics.parse(LrcLyrics.export(karaoke)) == karaoke)
    val bytes = ByteArray(180_000) { (it % 251).toByte() }.also {
        it[0] = 'I'.code.toByte(); it[1] = 'D'.code.toByte(); it[2] = '3'.code.toByte()
    }
    val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
    server.createContext("/track.mp3") { exchange ->
        exchange.responseHeaders.add("Content-Type", "audio/mpeg")
        exchange.responseHeaders.add("Accept-Ranges", "bytes")
        exchange.responseHeaders.add("ETag", "\"smoke-v1\"")
        if (exchange.requestMethod == "HEAD") {
            exchange.responseHeaders.add("Content-Length", bytes.size.toString())
            exchange.sendResponseHeaders(200, -1)
        } else {
            val range = exchange.requestHeaders.getFirst("Range")
            val start = range?.removePrefix("bytes=")?.substringBefore('-')?.toIntOrNull() ?: 0
            val end = range?.substringAfter('-')?.toIntOrNull()?.coerceAtMost(bytes.lastIndex) ?: bytes.lastIndex
            val body = bytes.copyOfRange(start, end + 1)
            if (range != null) exchange.responseHeaders.add("Content-Range", "bytes $start-$end/${bytes.size}")
            exchange.sendResponseHeaders(if (range != null) 206 else 200, body.size.toLong())
            exchange.responseBody.use { it.write(body) }
        }
        exchange.close()
    }
    server.start()
    val root = Files.createTempDirectory("veltrax-smoke").toFile()
    val url = "http://127.0.0.1:${server.address.port}/track.mp3"
    val stop = AtomicBoolean(false)
    try {
        val downloader = DirectAudioDownloader()
        var paused = false
        try {
            downloader.download(url, root, "resume_test", "track.mp3", stopped = { stop.get() }) { progress ->
                if (progress.transferred > 0L) stop.set(true)
            }
        } catch (_: DirectAudioDownloader.Paused) { paused = true }
        check(paused) { "pause should retain partial download" }
        check(File(root, "resume_test.single.part").length() > 0L) { "pause should preserve downloaded bytes" }
        stop.set(false)
        val completed = downloader.download(url, root, "resume_test", "track.mp3", stopped = { stop.get() })
        check(completed.readBytes().contentEquals(bytes)) { "resumed bytes differ" }
        println("portable library round-trip: OK")
        println("LRC word-timing round-trip: OK")
        println("HTTP Range partial-download resume + audio signature: OK")
    } finally {
        server.stop(0)
        root.deleteRecursively()
    }
}
