#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/core/src/main/kotlin/com/veltrax/core/PortableLibrary.kt" \
  "$ROOT/core/src/main/kotlin/com/veltrax/core/DirectAudioDownloader.kt" \
  "$ROOT/core/src/main/kotlin/com/veltrax/core/Lyrics.kt" \
  "$ROOT/tools/CoreSmoke.kt" \
  -include-runtime -d "$OUT/core-smoke.jar"
java -jar "$OUT/core-smoke.jar"
