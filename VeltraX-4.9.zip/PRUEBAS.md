# VeltraX 4.9 — plan de pruebas y estado

## Pruebas automatizadas añadidas

- [x] Test de ida y vuelta del formato `.vtxlib`, incluyendo Unicode y separadores en nombres.
- [x] Test del parser Lyricsfile para líneas con marcas de tiempo por palabra.
- [ ] Ejecutar `./gradlew test` en un entorno con Gradle y dependencias disponibles.

## Android

- [ ] `./gradlew :androidApp:assembleDebug`.
- [ ] Reproducir con pantalla apagada y verificar controles de notificación/auriculares.
- [ ] Probar fundido de salida/entrada con varias pistas, pausa, siguiente manual, repetición y cola de una sola canción.
- [ ] Comprobar que el fundido no deja el volumen en cero si se cambia de pista o se desactiva durante una transición.
- [ ] Editar título/artista/álbum y aceptar el diálogo de permiso de MediaStore (Android 11+); comprobar que la biblioteca muestra los nuevos campos.
- [ ] En Android 10, comprobar edición de un archivo propio y denegación segura en archivos ajenos.
- [ ] Obtener letras Lyricsfile con `words[]`; comprobar que el texto se resalta palabra a palabra. Probar también LRC normal y letras sin sincronización.
- [ ] Traducir una letra EN→ES; verificar la sincronización por línea, la caché, el manejo de errores y el límite diario del proveedor.
- [ ] Exportar `.vtxlib`, reinstalar/restaurar en otro dispositivo y comprobar favoritos/playlists enlazados por título+artista.
- [ ] Pausar y reanudar descargas Range; probar servidor que no soporte Range, URL inválida, corte de red y archivo de tipo incorrecto.
- [ ] Probar ecualizador y Bass Boost en varios dispositivos y después de reiniciar la app.

## Windows

- [ ] `gradle :desktopApp:compileKotlin`.
- [ ] `gradle :desktopApp:packageMsi` y abrir el MSI generado.
- [ ] Probar crossfade con 0, 1, 6 y 12 segundos; confirmar que se solapan las dos pistas y que skip/pausa/cambio de cola no deja reproductores huérfanos.
- [x] Invalidar callbacks asíncronos de crossfade al saltar o buscar otra posición.
- [x] Precargar el álbum actual en el editor de etiquetas para evitar borrados accidentales.
- [ ] Editar etiquetas ID3 en MP3 y etiquetas compatibles en M4A/FLAC; comprobar errores en formatos no escribibles.
- [ ] Exportar/importar `.vtxlib` entre Windows y Android.
- [ ] Pausar/reanudar descargas y reiniciar la aplicación con trabajos pendientes.

## Estado actual (4.9)

- [x] ZIP generado y comprobado con `unzip -t`.
- [ ] Compilación Android no ejecutada: Gradle 8.14.3 no pudo descargarse por `UnknownHostException: services.gradle.org`.
- [ ] Compilación Windows/MSI no ejecutada en este entorno.
- [ ] Pruebas de reproducción y permisos requieren dispositivos/sistema operativo reales.

No se debe considerar APK o MSI certificado hasta completar los pasos pendientes en Android Studio/GitHub Actions y Windows.

## Verificaciones ejecutadas en este entorno

- [x] `tools/verify-core.sh`: ida y vuelta del archivo `.vtxlib` con Unicode y separadores.
- [x] `tools/verify-core.sh`: ida y vuelta LRC con marcas de tiempo por palabra.
- [x] `tools/verify-core.sh`: descarga HTTP Range interrumpida tras recibir bytes, conservación del fragmento y reanudación hasta completar; se valida la firma de audio.
- [ ] Suite Gradle completa: bloqueada porque no se pudo resolver `services.gradle.org` para descargar Gradle 8.14.3.
