package com.veltrax.core

/** Transport-neutral contract for a future authenticated VeltraX sync service. */
object CloudSyncProtocol {
    const val CURRENT_SCHEMA = 1
    const val MAX_PLAYLISTS = 500
    const val MAX_TRACKS_PER_PLAYLIST = 5_000
    const val MAX_FAVORITES = 10_000

    data class PlaylistRecord(
        val id: String,
        val name: String,
        val trackIds: List<String>,
        val modifiedAtEpochMs: Long,
        val deleted: Boolean = false
    )

    data class LibrarySnapshot(
        val schemaVersion: Int = CURRENT_SCHEMA,
        val revision: String? = null,
        val favorites: Set<String>,
        val playlists: List<PlaylistRecord>,
        val updatedAtEpochMs: Long
    )

    enum class ValidationError { UNSUPPORTED_SCHEMA, TOO_MANY_FAVORITES, TOO_MANY_PLAYLISTS, INVALID_FAVORITE, INVALID_PLAYLIST, TOO_MANY_TRACKS }

    fun validate(snapshot: LibrarySnapshot): ValidationError? {
        if (snapshot.schemaVersion != CURRENT_SCHEMA) return ValidationError.UNSUPPORTED_SCHEMA
        if (snapshot.favorites.size > MAX_FAVORITES) return ValidationError.TOO_MANY_FAVORITES
        if (snapshot.playlists.size > MAX_PLAYLISTS) return ValidationError.TOO_MANY_PLAYLISTS
        if (snapshot.favorites.any { it.isBlank() || it.length > 512 }) return ValidationError.INVALID_FAVORITE
        for (playlist in snapshot.playlists) {
            if (playlist.id.isBlank() || playlist.id.length > 128 || playlist.name.isBlank() || playlist.name.length > 45 || playlist.modifiedAtEpochMs < 0)
                return ValidationError.INVALID_PLAYLIST
            if (playlist.trackIds.size > MAX_TRACKS_PER_PLAYLIST) return ValidationError.TOO_MANY_TRACKS
            if (playlist.trackIds.any { it.isBlank() || it.length > 512 }) return ValidationError.INVALID_PLAYLIST
        }
        return null
    }

    /** Last-write-wins per stable playlist ID; ties prefer the local record for deterministic behavior. */
    fun mergePlaylists(local: List<PlaylistRecord>, remote: List<PlaylistRecord>): List<PlaylistRecord> {
        val merged = LinkedHashMap<String, PlaylistRecord>()
        (remote + local).forEach { incoming ->
            val current = merged[incoming.id]
            if (current == null || incoming.modifiedAtEpochMs >= current.modifiedAtEpochMs) merged[incoming.id] = incoming
        }
        return merged.values.sortedBy { it.id }
    }

    /** Cloud API endpoints must use HTTPS; credentials must never be sent to cleartext hosts. */
    fun isSecureEndpoint(endpoint: String): Boolean = try {
        val uri = java.net.URI(endpoint)
        uri.scheme.equals("https", ignoreCase = true) && !uri.host.isNullOrBlank() && uri.userInfo == null
    } catch (_: Exception) { false }
}
