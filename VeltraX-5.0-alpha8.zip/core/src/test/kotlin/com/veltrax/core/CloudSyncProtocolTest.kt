package com.veltrax.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class CloudSyncProtocolTest {
    @Test fun validatesSnapshotLimitsAndSchema() {
        val good = CloudSyncProtocol.LibrarySnapshot(favorites = setOf("track:1"), playlists = emptyList(), updatedAtEpochMs = 10)
        assertNull(CloudSyncProtocol.validate(good))
        assertEquals(CloudSyncProtocol.ValidationError.UNSUPPORTED_SCHEMA, CloudSyncProtocol.validate(good.copy(schemaVersion = 99)))
        assertEquals(CloudSyncProtocol.ValidationError.INVALID_FAVORITE, CloudSyncProtocol.validate(good.copy(favorites = setOf(" "))))
    }

    @Test fun mergesPerPlaylistAndPrefersLocalOnTimestampTie() {
        val old = CloudSyncProtocol.PlaylistRecord("p1", "Old", emptyList(), 10)
        val remote = CloudSyncProtocol.PlaylistRecord("p1", "Remote", listOf("a"), 20)
        val localTie = CloudSyncProtocol.PlaylistRecord("p1", "Local", listOf("b"), 20)
        assertEquals("Remote", CloudSyncProtocol.mergePlaylists(listOf(old), listOf(remote)).single().name)
        assertEquals("Local", CloudSyncProtocol.mergePlaylists(listOf(localTie), listOf(remote)).single().name)
    }

    @Test fun onlyHttpsWithoutEmbeddedCredentialsIsAccepted() {
        assertTrue(CloudSyncProtocol.isSecureEndpoint("https://sync.example.com/v1"))
        assertFalse(CloudSyncProtocol.isSecureEndpoint("http://sync.example.com"))
        assertFalse(CloudSyncProtocol.isSecureEndpoint("https://user:pass@sync.example.com"))
    }
}
